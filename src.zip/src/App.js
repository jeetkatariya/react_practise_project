import React, {Component} from "react";
import RegisterationForm from "./UI/RegisterationForm";
import Login from "./UI/Login";
import LoginForm from "./UI/LoginForm"

class App extends Component {
    render() {
        return(
            <Login/>
            // <Home/>
            // <RegisterationForm/>
        );
    };
};

export default App;