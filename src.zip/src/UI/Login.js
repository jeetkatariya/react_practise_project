import React, {Component} from 'react';
import {Text,View,TextInput,Image,StyleSheet,KeyboardAvoidingView,TouchableOpacity} from 'react-native';
import LoginForm from './LoginForm';

class Login extends Component{
    render() {
        const {container, logoContainer, logo, titleStyle, formContainer, input, buttonContainer, buttonText} = styles;

        return(
            <KeyboardAvoidingView behavior="padding" style={container}>
                <View style={container}>
                    <View style={logoContainer}>
                        <Image 
                        style={logo}
                        source={require('../components/images/react_logo.jpg')}
                        />

                        <Text style={titleStyle}>Welcome to Our React Project</Text>
                    </View>
                        <View style={formContainer}>
                            <LoginForm/>
                        </View>
                </View>
            </KeyboardAvoidingView>
        )
    };
};

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#3498db'
    },

    logoContainer:{
        alignItems: 'center',
        flexGrow: 1,
        justifyContent: 'center'
    },

    logo:{
        height:100,
        width:100,
    },

    titleStyle:{
        color:'#FFF',
        marginTop:10,
        width:180,
        textAlign:'center',
        opacity:0.7,
    },

    formContainer:{
        padding:20,
    },
    
});

export default Login;