import React, { Component } from 'react';
import {View,Text,TextInput,TouchableOpacity,KeyboardAvoidingView,StyleSheet} from 'react-native';

class LoginForm extends Component {
    render() {
        const {container, input, buttonContainer, buttonText}=styles
        return (
            <View>
                    <TextInput 
                        placeholder="username"
                        placeholderTextColor="rgba(255,255,255,0.7)"
                        returnKeyType="next" //returns type of button in keyboard
                        onSubmitEditing={() => this.passwordInput.focus()}
                        style={input}/>

                    <TextInput 
                        placeholder="password"
                        placeholderTextColor="rgba(255,255,255,0.7)"
                        returnKeyType="go"
                        ref={(input) => this.passwordInput = input}
                        style={input}/>

                    <TouchableOpacity styles={buttonContainer}>
                        <Text style={buttonText}>LOGIN</Text>
                    </TouchableOpacity>
            </View>
        )
    };
};

const styles = StyleSheet.create ({
    container:{
        padding: 20,
    },
    input:{
        height: 40,
        backgroundColor:'rgba(255,255,255,0.3)',
        marginBottom: 10,
        paddingHorizontal: 10,
        color:'#FFF',
    },

    buttonContainer:{
        backgroundColor: '#2980b9',
        paddingVertical: 15,
    },

    buttonText:{
        textAlign: 'center',
        color: '#FFF',
        fontWeight: '700',
    },

});

export default LoginForm